import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { currentCity } from '../home/home.component';
import { GetCityService } from '../_services/get-city.service';

@Component({
  selector: 'app-sub-data',
  templateUrl: './sub-data.component.html',
  styleUrls: ['./sub-data.component.scss'],
})
export class SubDataComponent implements OnInit {
  city: string = '';
  ct: string = '';
  currentCityList: currentCity[] = [];
  items: any = [];

  constructor(private route: ActivatedRoute, private service: GetCityService) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      debugger;
      if (params['city']) {
        this.city = params['city'];
        this.ct = this.city.split(':')[1];
        this.getviewdetail(this.ct);
        console.log(this.city);
      }
    });
  }
  getviewdetail(city: string) {
    this.service.getCity(city).subscribe((data) => {
      this.items = data;
    });
  }
}
