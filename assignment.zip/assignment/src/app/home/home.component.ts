import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { citydt } from '../models/citydata';
import { GetCityService } from '../_services/get-city.service';
export interface currentCity {
  cityName: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  constructor(private service: GetCityService, private router: Router) {}

  currentCityList: currentCity[] = [];
  data: any = [];
  ngOnInit(): void {
    this.currentCityList = [
      {
        cityName: 'London',
      },
      {
        cityName: 'Edinburgh',
      },
      {
        cityName: 'Manchester',
      },
      {
        cityName: 'Glasgow',
      },
      {
        cityName: 'Coventry',
      },
    ];
    this.getCity();
  }
  getCity() {
    this.currentCityList.forEach((element) => {
      this.service.getCity(element.cityName).subscribe(
        res => {
          this.data.push(res);

        },
        (error) => {}
      );
    });
    console.log(this.data);
  }
  getweather(cityName:string) {

    this.router.navigate(['cityName/:'+cityName]);
  }
}
