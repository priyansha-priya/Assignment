import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { citydt } from '../models/citydata';
@Injectable({
  providedIn: 'root'
})
export class GetCityService {

  constructor(private http: HttpClient) { }
  getCity(city:string){
    var url='http://api.openweathermap.org/data/2.5/weather?q='+city+',uk&appid=3d8b309701a13f65b660fa2c64cdc517';
    return this.http.get<citydt>(url);
  }

}
